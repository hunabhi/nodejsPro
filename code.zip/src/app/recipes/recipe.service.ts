
import {EventEmitter} from '@angular/core';
import { Ingredient } from '../shared/ingredient.model';
import {Recipe} from './recipe.model';

export class RecipeService {
    recipes: Recipe[] = [
        new Recipe('Tasty Schnitzel', 
        'A super-tasty Schnitzel - just Awesome!', 
        'https://upload.wikimedia.org/wikipedia/commons/7/72/Schnitzel.JPG',
        [
            new Ingredient('meat',1),
            new Ingredient('French Fires',20)
        ]
        ),
        new Recipe('Big Fat Burger',
         'What else you need to say?', 
         'https://upload.wikimedia.org/wikipedia/commons/b/be/Burger_King_Angus_Bacon_%26_Cheese_Steak_Burger.jpg',
         [
             new Ingredient('Meat',1),
             new Ingredient('Buns',2)
         ]
         )
      ];
recipeSelected = new EventEmitter<Recipe>();

      getRecipe()
      {
        return this.recipes.slice();
      }
}